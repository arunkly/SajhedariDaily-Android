plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Firebase is configured only when the publisher supplies its own google-services.json.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

android {
    namespace = "com.sajhedaridaily.news"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sajhedaridaily.news"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.0"
        buildConfigField("String", "WORDPRESS_BASE_URL", "\"https://www.sajhedaridaily.com/\"")
    }
    signingConfigs {
        create("release") {
            val props = rootProject.file("local.properties")
            val local = java.util.Properties().apply { if (props.exists()) props.inputStream().use { load(it) } }
            val storePath = System.getenv("SAJHEDARI_STORE_FILE") ?: local.getProperty("SAJHEDARI_STORE_FILE")
            val storePass = System.getenv("SAJHEDARI_STORE_PASSWORD") ?: local.getProperty("SAJHEDARI_STORE_PASSWORD")
            val alias = System.getenv("SAJHEDARI_KEY_ALIAS") ?: local.getProperty("SAJHEDARI_KEY_ALIAS")
            val keyPass = System.getenv("SAJHEDARI_KEY_PASSWORD") ?: local.getProperty("SAJHEDARI_KEY_PASSWORD")
            if (!storePath.isNullOrBlank() && !storePass.isNullOrBlank() && !alias.isNullOrBlank() && !keyPass.isNullOrBlank()) {
                storeFile = file(storePath)
                storePassword = storePass
                keyAlias = alias
                keyPassword = keyPass
            }
        }
    }
    buildTypes {
        getByName("release") {
            // A release built without signing properties is intentionally unsigned.
            // Configure the four SAJHEDARI_* values before generating Play Store artifacts.
            val signingProps = java.util.Properties().apply {
                val propsFile = rootProject.file("local.properties")
                if (propsFile.exists()) propsFile.inputStream().use { load(it) }
            }
            fun signingValue(key: String) = System.getenv(key) ?: signingProps.getProperty(key)
            val signingConfigured = listOf("SAJHEDARI_STORE_FILE", "SAJHEDARI_STORE_PASSWORD", "SAJHEDARI_KEY_ALIAS", "SAJHEDARI_KEY_PASSWORD")
                .all { !signingValue(it).isNullOrBlank() }
            if (signingConfigured) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("com.google.code.gson:gson:2.11.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    // AdMob is integrated but remains inactive until the publisher enables it.
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-messaging-ktx")
    implementation("io.coil-kt:coil-compose:2.7.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
