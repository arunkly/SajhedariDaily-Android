package com.sajhedaridaily.news

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.sajhedaridaily.news.data.cache.OfflineNewsCache
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.content.Intent
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.sajhedaridaily.news.data.api.ApiClient
import com.sajhedaridaily.news.data.model.WpCategory
import com.sajhedaridaily.news.data.model.WpPost
import com.sajhedaridaily.news.data.repository.NewsRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF17212B)
private val Muted = Color(0xFF77818B)
private val Paper = Color(0xFFF5F6F8)
private val Maroon = Color(0xFF9B2638)
private val Gold = Color(0xFFD7A84B)

private data class PublisherAdConfig(
    val enabled: Boolean = false,
    val admobEnabled: Boolean = false,
    val directEnabled: Boolean = false,
    val bannerUnitId: String = "",
    val interstitialUnitId: String = "",
    val directTitle: String = "",
    val directDescription: String = "",
    val directImage: String = "",
    val directUrl: String = "",
    val showAfterStories: Int = 5,
    val interstitialEvery: Int = 0
)

private object PublisherAds {
    private const val CONFIG_URL = "https://www.sajhedaridaily.com/wp-json/sajhedari/v1/ads/config"
    suspend fun fetch(): PublisherAdConfig = kotlinx.coroutines.withContext(Dispatchers.IO) {
        runCatching {
            val request = okhttp3.Request.Builder().url(CONFIG_URL).get().build()
            val response = okhttp3.OkHttpClient().newCall(request).execute()
            response.use {
                if (!it.isSuccessful) return@withContext PublisherAdConfig()
                val json = JSONObject(it.body?.string().orEmpty())
                PublisherAdConfig(
                    enabled = json.optBoolean("enabled", false),
                    admobEnabled = json.optBoolean("admob_enabled", false),
                    directEnabled = json.optBoolean("direct_enabled", false),
                    bannerUnitId = json.optString("banner_unit_id", ""),
                    interstitialUnitId = json.optString("interstitial_unit_id", ""),
                    directTitle = json.optString("direct_title", ""),
                    directDescription = json.optString("direct_description", ""),
                    directImage = json.optString("direct_image", ""),
                    directUrl = json.optString("direct_url", ""),
                    showAfterStories = json.optInt("show_after_stories", 5).coerceIn(2, 20),
                    interstitialEvery = json.optInt("interstitial_every", 0).coerceIn(0, 20)
                )
            }
        }.getOrDefault(PublisherAdConfig())
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRuntime.context = applicationContext
        subscribeToNewsTopic()
        setContent { SajhedariTheme { SajhedariApp() } }
    }

    private fun subscribeToNewsTopic() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            val prefs = getSharedPreferences("sajhedari_permissions", MODE_PRIVATE)
            if (!prefs.getBoolean("notification_prompted", false)) {
                prefs.edit().putBoolean("notification_prompted", true).apply()
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
            }
        }
        // Firebase requires the publisher's google-services.json. Keep the app usable without it.
        runCatching { FirebaseMessaging.getInstance().subscribeToTopic("news") }
    }
}

@Composable
private fun SajhedariTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Maroon, onPrimary = Color.White, background = Paper, surface = Color.White, onSurface = Ink),
        typography = Typography(), content = content
    )
}

private data class HomeState(
    val loading: Boolean = true,
    val posts: List<WpPost> = emptyList(),
    val categories: List<WpCategory> = emptyList(),
    val error: String? = null,
    val selectedCategory: Long? = null,
    val article: WpPost? = null,
    val related: List<WpPost> = emptyList(),
    val articleLoading: Boolean = false,
    val savedPosts: List<WpPost> = emptyList()
)

private class NewsViewModel : ViewModel() {
    private val repository = NewsRepository(ApiClient.wordpress)
    var state by mutableStateOf(HomeState())
        private set

    init { refresh() }

    fun openArticle(post: WpPost) {
        viewModelScope.launch {
            state = state.copy(articleLoading = true, article = post, related = emptyList())
            try {
                val full = repository.article(post.id)
                OfflineNewsCache.saveArticle(AppRuntime.context, full)
                val categoryIds = full.categories.toSet()
                val related = repository.latest().filter { it.id != full.id && (categoryIds.isEmpty() || it.categories.any(categoryIds::contains)) }.take(5)
                state = state.copy(article = full, related = related, articleLoading = false)
            } catch (_: Exception) {
                state = state.copy(article = OfflineNewsCache.loadArticle(AppRuntime.context, post.id) ?: post, articleLoading = false)
            }
        }
    }

    fun closeArticle() { state = state.copy(article = null, related = emptyList(), articleLoading = false) }

    fun loadSaved(ids: Set<Long>) {
        viewModelScope.launch {
            val loaded = mutableListOf<WpPost>()
            ids.sortedDescending().forEach { id ->
                try { loaded += repository.article(id) } catch (_: Exception) { }
            }
            state = state.copy(savedPosts = loaded)
        }
    }

    fun refresh(categoryId: Long? = state.selectedCategory) {
        viewModelScope.launch {
            state = state.copy(loading = true, error = null, selectedCategory = categoryId)
            try {
                val categories = if (state.categories.isEmpty()) repository.categories() else state.categories
                val posts = repository.latest(categoryId = categoryId)
                if (categoryId == null) OfflineNewsCache.savePosts(AppRuntime.context, posts)
                state = HomeState(loading = false, posts = posts, categories = categories, selectedCategory = categoryId)
            } catch (e: Exception) {
                val cached = if (categoryId == null) OfflineNewsCache.loadPosts(AppRuntime.context) else emptyList()
                state = state.copy(loading = false, posts = cached, error = if (cached.isNotEmpty()) null else (e.message ?: "Unable to connect"))
            }
        }
    }
}

private enum class AppTab { HOME, CATEGORIES, LATEST, SAVED, SETTINGS, WEATHER, EPAPER }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SajhedariApp(vm: NewsViewModel = viewModel()) {
    val state = vm.state
    var isNepali by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    val context = LocalContext.current
    var bookmarkedIds by remember { mutableStateOf(loadBookmarks(context)) }
    var adConfig by remember { mutableStateOf(PublisherAdConfig()) }
    LaunchedEffect(Unit) { adConfig = PublisherAds.fetch(); if (adConfig.enabled && adConfig.admobEnabled) runCatching { MobileAds.initialize(context) } }
    fun toggleBookmark(id: Long) {
        bookmarkedIds = if (id in bookmarkedIds) bookmarkedIds - id else bookmarkedIds + id
        saveBookmarks(context, bookmarkedIds)
    }

    val labels = if (isNepali) listOf("गृहपृष्ठ", "श्रेणी", "ताजा", "बुकमार्क", "सेटिङ")
        else listOf("Home", "Categories", "Latest", "Saved", "Settings")

    Scaffold(
        containerColor = Paper,
        topBar = {
            Column(Modifier.background(Color.White)) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 18.dp, end = 10.dp, top = 13.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(43.dp).clip(RoundedCornerShape(12.dp)).background(Maroon), contentAlignment = Alignment.Center) {
                        Text("स", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("साझेदारी डेली", color = Maroon, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 23.sp)
                        Text("SAJHEDARI DAILY  •  NEWS", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    }
                    IconButton(onClick = { isNepali = !isNepali }) {
                        Icon(Icons.Default.Language, contentDescription = "Change language", tint = Maroon)
                    }
                    IconButton(onClick = { vm.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh news", tint = Ink)
                    }
                    IconButton(onClick = { searchOpen = !searchOpen; searchText = "" }) {
                        Icon(if (searchOpen) Icons.Default.Close else Icons.Default.Search, contentDescription = "Search", tint = Ink)
                    }
                }
                if (searchOpen) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(12.dp)).background(Paper).padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Muted)
                        Spacer(Modifier.width(8.dp))
                        BasicTextField(value = searchText, onValueChange = { searchText = it }, modifier = Modifier.weight(1f), singleLine = true, decorationBox = { inner -> if (searchText.isEmpty()) Text(if (isNepali) "समाचार खोज्नुहोस्..." else "Search news...", color = Muted); inner() })
                    }
                }
                Row(Modifier.fillMaxWidth().height(3.dp).background(Brush.horizontalGradient(listOf(Maroon, Gold, Maroon)))) {}
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                val tabs = listOf(AppTab.HOME, AppTab.CATEGORIES, AppTab.LATEST, AppTab.SAVED, AppTab.SETTINGS)
                val icons = listOf(Icons.Default.Home, Icons.Default.Category, Icons.Default.Bolt, Icons.Default.BookmarkBorder, Icons.Default.Settings)
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab; if (tab == AppTab.LATEST || tab == AppTab.HOME) vm.refresh(null); if (tab == AppTab.SAVED) vm.loadSaved(bookmarkedIds) },
                        icon = { Icon(icons[index], contentDescription = labels[index]) },
                        label = { Text(labels[index], fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Maroon, selectedTextColor = Maroon, indicatorColor = Maroon.copy(alpha = .10f), unselectedIconColor = Muted)
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            BackHandler(enabled = selectedTab == AppTab.WEATHER || selectedTab == AppTab.EPAPER) { selectedTab = AppTab.SETTINGS }
            if (state.article != null) {
                BackHandler(enabled = true) { vm.closeArticle() }
                ArticleReader(
                    post = state.article!!, related = state.related, isNepali = isNepali,
                    loading = state.articleLoading, bookmarked = state.article!!.id in bookmarkedIds,
                    onBack = vm::closeArticle, onBookmark = { toggleBookmark(state.article!!.id); if (selectedTab == AppTab.SAVED) vm.loadSaved(bookmarkedIds) },
                    onOpenRelated = vm::openArticle
                )
            } else when (selectedTab) {
                AppTab.HOME, AppTab.LATEST -> HomeContent(state, isNepali, searchText, vm::refresh, adConfig = adConfig, onCategory = { selectedTab = AppTab.HOME; vm.refresh(it) }, onOpenArticle = vm::openArticle)
                AppTab.CATEGORIES -> CategoriesContent(state.categories, isNepali) { vm.refresh(it); selectedTab = AppTab.HOME }
                AppTab.SAVED -> {
                    val saved = state.savedPosts
                    if (saved.isEmpty()) SimpleStatePage(if (isNepali) "बुकमार्क गरिएका समाचार" else "Saved stories", if (isNepali) "समाचार पढ्दा बुकमार्क चिन्ह थिचेर पछि पढ्न सुरक्षित गर्नुहोस्।" else "Tap the bookmark icon on any story to save it for later.")
                    else HomeContent(state.copy(posts = saved, selectedCategory = null), isNepali, "", {}, adConfig = PublisherAdConfig(), onCategory = {}, onOpenArticle = vm::openArticle)
                }
                AppTab.WEATHER -> WeatherPage(isNepali)
                AppTab.EPAPER -> EpaperPage(isNepali)
                AppTab.SETTINGS -> SettingsPage(
                    isNepali,
                    onLanguage = { isNepali = !isNepali },
                    onEpaper = { selectedTab = AppTab.EPAPER },
                    onWeather = { selectedTab = AppTab.WEATHER },
                    onNotifications = { openNotificationSettings(context) },
                    adConfig = adConfig
                )
            }
        }
    }
}

@Composable
private fun HomeContent(state: HomeState, isNepali: Boolean, searchText: String, onRefresh: () -> Unit, adConfig: PublisherAdConfig, onCategory: (Long?) -> Unit, onOpenArticle: (WpPost) -> Unit) {
    val filtered = remember(state.posts, searchText) {
        if (searchText.isBlank()) state.posts else state.posts.filter { it.title?.rendered.orEmpty().decodeHtml().contains(searchText, true) }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().background(Maroon).padding(horizontal = 17.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = .17f)).padding(horizontal = 7.dp, vertical = 4.dp)) {
                    Text(if (isNepali) "ब्रेकिङ" else "BREAKING", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = .7.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text(if (isNepali) "देशभरका ताजा समाचार र अपडेट" else "Latest news and updates from across the country", color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        item {
            SectionHeading(if (isNepali) "समाचारका श्रेणीहरू" else "NEWS CATEGORIES", if (isNepali) "सबै हेर्नुहोस्" else "EXPLORE")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryPill(if (isNepali) "सबै" else "All", state.selectedCategory == null) { onCategory(null) }
                state.categories.take(12).forEach { category ->
                    CategoryPill(category.name, state.selectedCategory == category.id) { onCategory(category.id) }
                }
            }
            Spacer(Modifier.height(15.dp))
        }
        if (state.loading && state.posts.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Maroon) } }
        } else if (state.error != null && state.posts.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isNepali) "समाचार लोड हुन सकेन" else "Couldn't load news", fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(5.dp)); Text(state.error, color = Muted, fontSize = 12.sp, maxLines = 3)
                    Spacer(Modifier.height(12.dp)); Button(onClick = onRefresh, colors = ButtonDefaults.buttonColors(containerColor = Maroon)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text(if (isNepali) "पुनः प्रयास" else "Try again") }
                }
            }
        } else if (filtered.isEmpty()) {
            item { Text(if (isNepali) "समाचार भेटिएन" else "No stories found", modifier = Modifier.padding(24.dp), color = Muted) }
        } else {
            item {
                SectionHeading(if (isNepali) "मुख्य समाचार" else "TOP STORY", if (isNepali) "विशेष" else "FEATURED")
                FeaturedStory(filtered.first(), isNepali, onOpenArticle)
            }
            item { SectionHeading(if (isNepali) "ताजा समाचार" else "LATEST STORIES", if (isNepali) "अपडेट" else "JUST IN") }
            itemsIndexed(filtered.drop(1), key = { _, post -> post.id }) { index, post ->
                CompactNewsCard(post, isNepali, onOpenArticle)
                val placementIndex = index + 1
                if (adConfig.enabled && placementIndex == adConfig.showAfterStories) {
                    if (adConfig.directEnabled) DirectAdCard(adConfig, isNepali)
                    if (adConfig.admobEnabled && adConfig.bannerUnitId.isNotBlank()) AdMobBanner(adConfig.bannerUnitId)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun SectionHeading(title: String, tag: String) {
    Row(Modifier.fillMaxWidth().padding(start = 17.dp, end = 17.dp, top = 18.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(21.dp).clip(CircleShape).background(Maroon))
        Spacer(Modifier.width(9.dp))
        Text(title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        Text(tag, color = Maroon, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = .8.sp)
    }
}

@Composable
private fun CategoryPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(20.dp), color = if (selected) Maroon else Color.White, border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB))) {
        Text(label, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp), color = if (selected) Color.White else Ink, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun FeaturedStory(post: WpPost, isNepali: Boolean, onClick: (WpPost) -> Unit) {
    val title = post.title?.rendered.orEmpty().decodeHtml().ifBlank { if (isNepali) "शीर्षक उपलब्ध छैन" else "Headline unavailable" }
    val image = post.embedded?.featuredMedia?.firstOrNull()?.sourceUrl
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { onClick(post) }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(218.dp).background(Color(0xFFE7E9ED))) {
                if (!image.isNullOrBlank()) AsyncImage(model = image, contentDescription = title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .60f)), startY = 120f)))
                Text(if (isNepali) "विशेष समाचार" else "TOP STORY", modifier = Modifier.align(Alignment.TopStart).padding(13.dp).clip(RoundedCornerShape(5.dp)).background(Maroon).padding(horizontal = 9.dp, vertical = 6.dp), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = .6.sp)
            }
            Column(Modifier.padding(horizontal = 15.dp, vertical = 14.dp)) {
                Text(title, color = Ink, fontSize = 18.sp, lineHeight = 27.sp, fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                val excerpt = post.excerpt?.rendered.orEmpty().decodeHtml().trim()
                if (excerpt.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(excerpt, color = Muted, fontSize = 12.sp, lineHeight = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(post.embedded?.authors?.firstOrNull()?.name ?: "Sajhedari Daily", color = Maroon, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text(post.date?.take(10).orEmpty(), color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun CompactNewsCard(post: WpPost, isNepali: Boolean, onClick: (WpPost) -> Unit) {
    val title = post.title?.rendered.orEmpty().decodeHtml().ifBlank { if (isNepali) "शीर्षक उपलब्ध छैन" else "Headline unavailable" }
    val excerpt = post.excerpt?.rendered.orEmpty().decodeHtml().trim()
    val image = post.embedded?.featuredMedia?.firstOrNull()?.sourceUrl
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick(post) }, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.width(112.dp).height(94.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFE9EBEF))) {
                if (!image.isNullOrBlank()) AsyncImage(model = image, contentDescription = title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontSize = 14.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (excerpt.isNotBlank()) { Spacer(Modifier.height(5.dp)); Text(excerpt, color = Muted, fontSize = 10.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                Spacer(Modifier.height(6.dp))
                Text(post.date?.take(10).orEmpty(), color = Maroon, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun CategoriesContent(categories: List<WpCategory>, isNepali: Boolean, onSelect: (Long) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(if (isNepali) "समाचारका श्रेणीहरू" else "News categories", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Text(if (isNepali) "आफूलाई मनपर्ने विषयका समाचार छान्नुहोस्" else "Choose a topic to explore its latest stories", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
        if (categories.isEmpty()) Text(if (isNepali) "श्रेणीहरू लोड हुँदैछन् वा उपलब्ध छैनन्।" else "Categories are loading or unavailable.", color = Muted)
        categories.forEach { category ->
            Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onSelect(category.id) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(Maroon.copy(alpha = .09f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Category, null, tint = Maroon) }
                    Spacer(Modifier.width(12.dp)); Text(category.name, modifier = Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                    Text("${category.count ?: 0}", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SimpleStatePage(title: String, description: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.BookmarkBorder, null, tint = Maroon, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp)); Text(title, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp)); Text(description, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun DirectAdCard(config: PublisherAdConfig, isNepali: Boolean) {
    if (config.directTitle.isBlank() || config.directUrl.isBlank()) return
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).clickable { openExternal(AppRuntime.context, config.directUrl) }, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Campaign, null, tint = Maroon, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp)); Text(if (isNepali) "विज्ञापन" else "ADVERTISEMENT", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (isNepali) "प्रायोजित" else "Sponsored", color = Maroon, fontSize = 9.sp)
            }
            if (config.directImage.isNotBlank()) AsyncImage(model = config.directImage, contentDescription = config.directTitle, modifier = Modifier.fillMaxWidth().height(145.dp), contentScale = ContentScale.Crop)
            Column(Modifier.padding(13.dp)) {
                Text(config.directTitle, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                if (config.directDescription.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(config.directDescription, color = Muted, fontSize = 12.sp) }
                Spacer(Modifier.height(7.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text(if (isNepali) "थप जान्नुहोस्" else "Learn more", color = Maroon, fontSize = 11.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Icon(Icons.Default.OpenInNew, null, tint = Maroon, modifier = Modifier.size(13.dp)) }
            }
        }
    }
}

@Composable
private fun AdMobBanner(unitId: String) {
    val context = LocalContext.current
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp, vertical = 4.dp),
        factory = { viewContext -> AdView(viewContext).apply { setAdSize(AdSize.BANNER); adUnitId = unitId; loadAd(AdRequest.Builder().build()) } }
    )
}

@Composable
private fun SettingsPage(isNepali: Boolean, onLanguage: () -> Unit, onEpaper: () -> Unit, onWeather: () -> Unit, onNotifications: () -> Unit, adConfig: PublisherAdConfig) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(if (isNepali) "सेटिङ" else "Settings", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(15.dp))
        SettingsRow(if (isNepali) "भाषा" else "Language", if (isNepali) "नेपाली" else "English", Icons.Default.Language, onLanguage)
        Spacer(Modifier.height(9.dp))
        SettingsRow(if (isNepali) "ई-पेपर" else "E-paper", if (isNepali) "डिजिटल संस्करण हेर्नुहोस्" else "Open digital edition", Icons.Default.Article, onEpaper)
        Spacer(Modifier.height(9.dp))
        SettingsRow(if (isNepali) "मौसम" else "Weather", if (isNepali) "मौसम सेवा खोल्नुहोस्" else "Weather service information", Icons.Default.Cloud, onWeather)
        Spacer(Modifier.height(9.dp))
        SettingsRow(if (isNepali) "सूचना अनुमति" else "Notification permissions", if (isNepali) "एन्ड्रोइड सेटिङमा सूचना खोल्नुहोस्" else "Manage notifications in Android settings", Icons.Default.Campaign, onNotifications)
        Spacer(Modifier.height(9.dp))
        SettingsRow(if (isNepali) "विज्ञापन" else "Advertising", if (adConfig.enabled) (if (isNepali) "प्रकाशकद्वारा सक्रिय" else "Enabled by publisher") else (if (isNepali) "हाल बन्द छ" else "Currently disabled"), Icons.Default.Campaign) { }
        Spacer(Modifier.height(16.dp))
        Text(if (isNepali) "अफलाइन पढाइ: पछिल्लो समाचार इन्टरनेट हुँदा सुरक्षित हुन्छ।" else "Offline reading: latest stories are cached when online.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Text(if (isNepali) "नयाँ समाचार सूचना प्राप्त गर्न माथिको सूचना अनुमति विकल्प प्रयोग गर्नुहोस्।" else "Use Notification permissions above to enable or disable breaking news alerts.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Text("SAJHEDARI DAILY  •  v0.6.0", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(5.dp))
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Maroon); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Ink, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }
            Text("›", color = Maroon, fontSize = 24.sp)
        }
    }
}

private fun openExternal(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
}

private fun openNotificationSettings(context: Context) {
    val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
    } else {
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${context.packageName}"))
    }
    runCatching { context.startActivity(intent) }
}


@Composable
private fun WeatherPage(isNepali: Boolean) {
    var city by remember { mutableStateOf("Birgunj") }
    var result by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(if (isNepali) "मौसम जानकारी" else "Weather", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text(if (isNepali) "शहरको नाम लेखेर मौसम हेर्नुहोस्" else "Enter a city to check current weather", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text(if (isNepali) "शहर" else "City") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            if (city.isBlank()) return@Button
            loading = true; errorMessage = null; result = null
            scope.launch {
                val response = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    runCatching {
                        val client = okhttp3.OkHttpClient.Builder()
                            .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                            .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                            .callTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                            .build()
                        val encoded = java.net.URLEncoder.encode(city, "UTF-8")
                        val geoReq = okhttp3.Request.Builder().url("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json").build()
                        val geoBody = client.newCall(geoReq).execute().use { response ->
                            if (!response.isSuccessful) error("Weather location service returned HTTP ${response.code}")
                            response.body?.string().orEmpty()
                        }
                        val geo = org.json.JSONObject(geoBody)
                        val place = geo.optJSONArray("results")?.optJSONObject(0) ?: error("City not found")
                        val lat = place.getDouble("latitude"); val lon = place.getDouble("longitude")
                        val forecastReq = okhttp3.Request.Builder().url("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=auto").build()
                        val forecastBody = client.newCall(forecastReq).execute().use { response ->
                            if (!response.isSuccessful) error("Weather service returned HTTP ${response.code}")
                            response.body?.string().orEmpty()
                        }
                        val current = org.json.JSONObject(forecastBody).getJSONObject("current")
                        "${place.optString("name", city)} · ${current.optDouble("temperature_2m").toInt()}°C · ${current.optInt("relative_humidity_2m")}% humidity · ${current.optDouble("wind_speed_10m").toInt()} km/h wind"
                    }
                }
                response.onSuccess { result = it }.onFailure { errorMessage = it.message ?: "Weather unavailable" }
                loading = false
            }
        }, enabled = !loading, colors = ButtonDefaults.buttonColors(containerColor = Maroon)) {
            Text(if (loading) (if (isNepali) "लोड हुँदैछ..." else "Loading...") else (if (isNepali) "मौसम हेर्नुहोस्" else "Get weather"))
        }
        Spacer(Modifier.height(18.dp))
        result?.let { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Text(it, Modifier.padding(18.dp), color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold) } }
        errorMessage?.let { Text(it, color = Maroon, fontSize = 13.sp) }
        Spacer(Modifier.height(12.dp))
        Text(if (isNepali) "मौसम डेटा Open-Meteo बाट प्राप्त हुन्छ।" else "Weather data provided by Open-Meteo.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun EpaperPage(isNepali: Boolean) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Text(if (isNepali) "ई-पेपर" else "E-paper", color = Maroon, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp))
        Text(if (isNepali) "साझेदारी डेलीको ई-पेपर संस्करणको आधिकारिक लिंक उपलब्ध भएपछि यहाँ PDF सूची र संस्करण अभिलेख जोडिनेछ। अहिले वेबसाइट खोल्नुहोस्।" else "The E-paper archive and PDF viewer will be connected once the publisher's exact E-paper URL is confirmed. Open the official website for now.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 18.dp))
        Spacer(Modifier.height(14.dp))
        Button(onClick = { openExternal(context, "https://www.sajhedaridaily.com/") }, modifier = Modifier.padding(horizontal = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Maroon)) {
            Text(if (isNepali) "आधिकारिक वेबसाइट खोल्नुहोस्" else "Open official website")
        }
    }
}

private fun String.decodeHtml(): String = android.text.Html.fromHtml(this, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()


private fun loadBookmarks(context: Context): Set<Long> = context.getSharedPreferences("sajhedari_reader", Context.MODE_PRIVATE)
    .getStringSet("bookmarks", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

private fun saveBookmarks(context: Context, ids: Set<Long>) {
    context.getSharedPreferences("sajhedari_reader", Context.MODE_PRIVATE).edit()
        .putStringSet("bookmarks", ids.map { it.toString() }.toSet()).apply()
}

@Composable
private fun ArticleReader(
    post: WpPost,
    related: List<WpPost>,
    isNepali: Boolean,
    loading: Boolean,
    bookmarked: Boolean,
    onBack: () -> Unit,
    onBookmark: () -> Unit,
    onOpenRelated: (WpPost) -> Unit
) {
    val context = LocalContext.current
    var fontSize by remember(post.id) { mutableFloatStateOf(17f) }
    var speaking by remember(post.id) { mutableStateOf(false) }
    val tts = remember { TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) { /* ready */ } } }
    DisposableEffect(tts) { onDispose { tts.stop(); tts.shutdown() } }
    val title = post.title?.rendered.orEmpty().decodeHtml().ifBlank { if (isNepali) "शीर्षक उपलब्ध छैन" else "Headline unavailable" }
    val author = post.embedded?.authors?.firstOrNull()?.name ?: "Sajhedari Daily"
    val categories = post.embedded?.terms?.flatten()?.filter { it.id in post.categories }?.joinToString(" • ") { it.name }.orEmpty()
    val heroImage = post.embedded?.featuredMedia?.firstOrNull()?.sourceUrl
    val html = post.content?.rendered.orEmpty()
    val gallery = remember(html) {
        Regex("(?i)<img[^>]+src=[\\\"']([^\\\"']+)[\\\"']").findAll(html).map { it.groupValues[1] }.distinct().take(12).toList()
    }

    Column(Modifier.fillMaxSize().background(Paper)) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, contentDescription = if (isNepali) "फिर्ता" else "Back", tint = Ink) }
            Text(if (isNepali) "समाचार" else "ARTICLE", modifier = Modifier.weight(1f), color = Maroon, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            IconButton(onClick = {
                if (speaking) { tts.stop(); speaking = false }
                else {
                    val plain = android.text.Html.fromHtml(html.ifBlank { title }, android.text.Html.FROM_HTML_MODE_LEGACY).toString().take(3500)
                    tts.language = if (isNepali) Locale("ne", "NP") else Locale.ENGLISH
                    val result = tts.setLanguage(tts.language)
                    if (result >= TextToSpeech.LANG_AVAILABLE) { tts.speak("$title. $plain", TextToSpeech.QUEUE_FLUSH, null, "sajhedari_${post.id}"); speaking = true }
                }
            }) { Icon(Icons.Default.VolumeUp, contentDescription = if (isNepali) "समाचार सुन्नुहोस्" else "Listen to news", tint = if (speaking) Maroon else Ink) }
            IconButton(onClick = onBookmark) { Icon(if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = "Bookmark", tint = Maroon) }
            IconButton(onClick = {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, "$title\n${post.link.orEmpty()}")
                }
                context.startActivity(Intent.createChooser(share, if (isNepali) "समाचार शेयर गर्नुहोस्" else "Share article"))
            }) { Icon(Icons.Default.Share, contentDescription = "Share", tint = Ink) }
        }
        HorizontalDivider(color = Color(0xFFE8E9EC))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
            item {
                Column(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 18.dp, vertical = 18.dp)) {
                    if (categories.isNotBlank()) Text(categories.uppercase(), color = Maroon, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(9.dp))
                    Text(title, color = Ink, fontSize = 24.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(13.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(Maroon.copy(alpha = .10f)), contentAlignment = Alignment.Center) { Text("स", color = Maroon, fontWeight = FontWeight.Black) }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(author, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(post.date?.replace('T', ' ')?.take(16).orEmpty(), color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
            if (!heroImage.isNullOrBlank()) item {
                AsyncImage(model = heroImage, contentDescription = title, modifier = Modifier.fillMaxWidth().heightIn(min = 190.dp, max = 280.dp), contentScale = ContentScale.Crop)
            }
            item {
                Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (isNepali) "अक्षर आकार" else "TEXT SIZE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("A−", color = Maroon, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { fontSize = (fontSize - 1f).coerceAtLeast(14f) }.padding(horizontal = 10.dp, vertical = 5.dp))
                    Text("${fontSize.toInt()}", color = Ink, fontSize = 11.sp)
                    Text("A+", color = Maroon, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { fontSize = (fontSize + 1f).coerceAtMost(25f) }.padding(horizontal = 10.dp, vertical = 5.dp))
                }
            }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Maroon) }
            if (gallery.size > 1) item {
                Text(if (isNepali) "तस्बिरहरू" else "PHOTO GALLERY", modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 8.dp), color = Maroon, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    gallery.forEachIndexed { index, url ->
                        AsyncImage(model = url, contentDescription = "${if (isNepali) "तस्बिर" else "Photo"} ${index + 1}", modifier = Modifier.width(190.dp).height(125.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    }
                }
            }
            item {
                if (html.isNotBlank()) {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 250.dp),
                        factory = { ctx -> WebView(ctx).apply {
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                                    val uri = request.url
                                    val host = uri.host.orEmpty().lowercase()
                                    if (host == "sajhedaridaily.com" || host.endsWith(".sajhedaridaily.com")) return false
                                    runCatching { openExternal(context, uri.toString()) }
                                    return true
                                }
                            }
                            settings.javaScriptEnabled = false
                            settings.domStorageEnabled = false
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.allowUniversalAccessFromFileURLs = false
                            settings.allowFileAccessFromFileURLs = false
                            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            setBackgroundColor(android.graphics.Color.WHITE)
                        } },
                        update = { webView ->
                            val css = "body{font-family:sans-serif;color:#26313b;font-size:${fontSize}px;line-height:1.85;margin:18px 18px 26px;} img{max-width:100%;height:auto;border-radius:8px;} iframe,video{max-width:100%;} a{color:#9b2638;} blockquote{border-left:3px solid #9b2638;margin-left:0;padding-left:12px;color:#68727c;} p{margin:0 0 16px;}"
                            val page = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'><style>$css</style></head><body>$html</body></html>"
                            webView.loadDataWithBaseURL(post.link ?: "https://www.sajhedaridaily.com/", page, "text/html", "UTF-8", null)
                        }
                    )
                } else Text(if (isNepali) "समाचारको पूरा सामग्री उपलब्ध छैन।" else "Full article content is unavailable.", modifier = Modifier.padding(20.dp), color = Muted)
            }
            if (related.isNotEmpty()) item {
                SectionHeading(if (isNepali) "सम्बन्धित समाचार" else "RELATED STORIES", if (isNepali) "थप पढ्नुहोस्" else "READ MORE")
            }
            items(related, key = { "related-${it.id}" }) { item -> CompactNewsCard(item, isNepali, onOpenRelated) }
            item {
                Text("www.sajhedaridaily.com", modifier = Modifier.fillMaxWidth().padding(22.dp), color = Muted, fontSize = 10.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}
