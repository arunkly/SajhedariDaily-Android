# Sajhedari Daily Android – Phase 4

This package continues the Phase 3 Android Studio source. Phase 4 adds the Android-side foundations for push alerts, cached reading, Nepali/English text-to-speech, and an Open-Meteo weather lookup.

## Included in this phase

- Firebase Cloud Messaging client service and `news` topic subscription.
- Android 13+ notification permission request and notification channel.
- WordPress plugin to send a Firebase HTTP v1 topic notification when a standard WordPress `post` is first published.
- On-device JSON cache of the latest public posts and opened article content for offline fallback.
- Article listen button using Android TextToSpeech (Nepali locale `ne-NP` / English).
- In-app city weather lookup using Open-Meteo geocoding and forecast APIs. City is user-entered; no location permission is requested.
- E-paper entry point. The actual archive/PDF viewer is deliberately not guessed: configure the publisher's real E-paper URL/post type before enabling a production PDF archive.

## Firebase setup (required for real push delivery)

1. Create or select a Firebase project for Sajhedari Daily.
2. Add an Android app with package name `com.sajhedaridaily.news`.
3. Download `google-services.json` and place it at `app/google-services.json` (never commit this file to a public repository).
4. In the root `build.gradle.kts`, add to the `plugins` block:

   ```kotlin
   id("com.google.gms.google-services") version "4.4.2" apply false
   ```

5. In `app/build.gradle.kts`, add to the `plugins` block:

   ```kotlin
   id("com.google.gms.google-services")
   ```

6. Sync Gradle, install on a device, and allow notifications. The app subscribes to the FCM topic `news`.
7. In Firebase Console, ensure Firebase Cloud Messaging API is enabled.

The source intentionally does not contain a Firebase project configuration or service-account private key. Push delivery cannot work until the publisher configures its own Firebase project.

## WordPress publisher setup

Plugin source is in `wordpress-plugin/sajhedari-fcm-publisher/`.

1. Create a Firebase service account with permission to send Firebase Cloud Messaging messages for this Firebase project.
2. Download its JSON key and store it **outside the public web root**, readable only by the PHP/web-server account.
3. Add this constant to `wp-config.php` with the real absolute path:

   ```php
   define('SAJHEDARI_FCM_SERVICE_ACCOUNT_PATH', '/secure/path/firebase-service-account.json');
   ```

4. Upload and activate `sajhedari-fcm-publisher.zip` as a WordPress plugin.
5. Publish a new standard WordPress post. The plugin sends a message to topic `news` only on the first transition into `publish`.

Do not put the service-account JSON in the plugin directory, Media Library, public Git repository, or web-accessible folder. The plugin currently targets standard `post` entries; if Sajhedari Daily uses a custom post type for news, adjust the allowed `post_type` after confirming its exact slug. Test with a staging post before production.

## Offline behavior

The app stores the latest unfiltered feed and each successfully opened article in private app storage. If the next feed request fails, the cached latest feed is shown. Previously opened articles can be reopened from the app's existing saved/bookmarked flow while their cache remains available. This is a lightweight cache, not a full background download manager or an unlimited offline archive.

## Weather

Weather uses Open-Meteo public geocoding and forecast endpoints. The user enters a city name. No GPS permission or location tracking is used. Network access is required for a fresh result.

## E-paper integration still needs publisher input

The exact E-paper archive URL, PDF URL pattern, and whether E-paper is represented by a WordPress page, custom post type, or external provider have not yet been confirmed. The app includes an E-paper entry point but currently opens the official website as a fallback. Supply the actual archive URL and PDF format to complete an in-app archive and PDF viewer without inventing a route.

## Build and verification

Open the `SajhedariDaily-Android-Phase1` folder in Android Studio (JDK 17, Android SDK 35). Sync Gradle and build the debug APK. This workspace did not have an Android SDK/Gradle build environment, so APK compilation and device-side Firebase/TTS testing have not been certified here.
