# Sajhedari Daily Android — Phase 0 & Phase 1

Native Android starter using Kotlin, Jetpack Compose and the public WordPress REST API.

## Confirmed project settings
- Application ID: `com.sajhedaridaily.news`
- Website: `https://www.sajhedaridaily.com/`
- UI: Kotlin + Jetpack Compose
- Language resources: Nepali (`values-ne`) and English (`values`)
- Advertising: disabled
- Minimum Android: API 26 / Android 8.0

## Implemented in this starter
- Android project and Gradle configuration
- Internet permission and HTTPS-only networking
- Retrofit + Gson WordPress API client
- Latest posts endpoint with `_embed` for featured images and author data
- Single post and categories API methods
- Repository layer
- Basic premium newspaper-inspired home feed
- Loading, empty and error states; manual refresh
- Nepali and English Android string resources

## API endpoints used
- `GET /wp-json/wp/v2/posts?page=1&per_page=20&_embed=true`
- `GET /wp-json/wp/v2/posts/{id}?_embed=true`
- `GET /wp-json/wp/v2/categories?page=1&per_page=100&hide_empty=true`

## Open in Android Studio
1. Open this folder as an existing Gradle project.
2. Use JDK 17 and install Android SDK Platform 35.
3. Allow Gradle sync to download dependencies.
4. Run on an Android 8.0+ device or emulator.

## Important verification before production
The web inspection environment could not retrieve the live `/wp-json/` endpoints during preparation. This is not proof that the API is disabled. Run the three endpoints above in a browser or curl from your network. If WordPress blocks REST API requests, inspect security/cache plugins and hosting firewall rules. Do not disable security globally; allow the public read-only REST endpoints instead.

## Current scope / not yet implemented
This is Phase 0 and Phase 1 only. Article detail navigation, durable offline cache, full category UI, push notification server integration, e-paper viewer, language toggle UI, analytics and release signing are later phases. No advertising SDK is included.

## Notes
- API models are intentionally tolerant of missing author/featured-media fields.
- The app does not contain WordPress credentials.
- The API base URL is defined in `app/build.gradle.kts` as a build config value.
- Before release, verify actual site category names, custom post types/taxonomies and article HTML structure.

## Phase 2 — Premium Android home screen

### Implemented
- Premium newspaper-style Sajhedari Daily header and maroon/gold identity
- Nepali / English in-app language toggle
- Breaking-news strip
- WordPress-driven horizontal category chips
- Category browsing screen with category counts
- Featured lead-story card with large featured image
- Latest-news feed with image, headline, excerpt, author/date metadata
- Search field filtering the currently loaded feed
- Five-item bottom navigation: Home, Categories, Latest, Saved, Settings
- Manual news refresh action in the app header; retry is also available on API failure
- Loading, empty and error states
- Category selection calls the WordPress posts endpoint with the `categories` query parameter
- No advertising SDK or ad placements have been added

### Phase 2 scope notes
- Article detail navigation, durable bookmarks, push notifications, e-paper and offline database are intentionally reserved for later phases.
- Search currently filters the loaded page of posts; server-side search pagination can be expanded in a later discovery/search phase.
- Category labels are loaded from WordPress rather than hardcoded. The language toggle changes app navigation and interface labels; article titles remain in the language published by the website.
- The header mark is a temporary typographic monogram until official Sajhedari Daily logo assets are supplied.

### Verification
- Source and XML structure reviewed; ZIP archive integrity checked.
- APK compilation and device testing have not been claimed because this build environment does not include an Android SDK/Gradle installation. Open in Android Studio with JDK 17 and Android SDK Platform 35, sync Gradle, then run on a device/emulator.

## Phase 3 – News reading experience

Phase 3 adds a native article-reading flow on top of the Phase 0–2 app foundation:

- Tap the featured story or a news card to open the article reader.
- The reader requests the full WordPress post by ID, including `_embed` metadata.
- Displays headline, category (when embedded terms are available), author, publication date, featured image and rendered article HTML.
- Uses a JavaScript-disabled Android WebView with file/content access disabled to render WordPress rich article content and inline images.
- Includes a horizontally browsable image strip extracted from article HTML.
- Provides in-app text-size controls for article content.
- Shares the article headline and canonical WordPress URL through Android's native share sheet (WhatsApp/Facebook appear when installed).
- Persists bookmarks locally with SharedPreferences and reloads saved post IDs from WordPress.
- Displays related posts selected by shared WordPress category IDs.

### Phase 3 testing notes

- Verify the public REST API returns `content.rendered`, `_embedded.wp:featuredmedia`, `_embedded.author`, and `_embedded.wp:term` for the site's posts.
- Confirm the WordPress content HTML does not rely on JavaScript-only embeds; JavaScript is intentionally disabled in the article WebView.
- Test bookmark persistence after force-close/relaunch and when a bookmarked post is no longer in the latest feed.
- Test native sharing with WhatsApp and Facebook installed and not installed.
- Validate image gallery extraction against the site's actual article HTML (lazy-loaded images may use `data-src` instead of `src`).
- Run Gradle sync, assembleDebug, and device tests in Android Studio before release. APK compilation has not been certified in this environment because no Gradle wrapper executable/build environment is bundled with the supplied Phase 2 archive.

## Phase 4 additions

See `PHASE4-SETUP.md` for Firebase setup, WordPress publisher plugin installation, offline cache behavior, weather integration, and the E-paper URL dependency. Firebase credentials are intentionally not included.


## Phase 5 — Publisher-controlled advertising (disabled by default)

### Android app
- Added Google Mobile Ads SDK dependency. The SDK is not initialized unless the public WordPress configuration enables AdMob.
- Added an AdMob banner placement in the home feed, positioned after the configured number of story cards.
- Added a publisher-managed direct-ad card with sponsored label, optional image, title, description and destination link.
- Added an advertising status row in Settings. The app cannot turn advertising on itself; the publisher controls it in WordPress.
- Ads are globally disabled by default. Missing/unavailable configuration also fails closed to no ads.

### WordPress plugin
Install `wordpress-plugin/sajhedari-mobile-ads/sajhedari-mobile-ads.php` as a plugin (or install the supplied standalone plugin ZIP). Configure it under **Settings → Sajhedari Mobile Ads**. The public read-only endpoint is `/wp-json/sajhedari/v1/ads/config`. It exposes only app placement configuration, not credentials.

### Before enabling production AdMob
1. Create the Sajhedari Daily app in Google AdMob.
2. Replace the Google sample App ID in `app/src/main/AndroidManifest.xml` with the real AdMob App ID.
3. Add the real banner ad unit ID in WordPress plugin settings.
4. Test with Google test ad units and test devices first. Never click live ads during testing.
5. Only then enable the global advertising switch and AdMob switch in WordPress.

### Frequency and safety
- Direct/banner placement frequency is publisher-configurable (2–20 story cards; default 5).
- An interstitial frequency setting is exposed for future use but interstitials are deliberately not displayed in this release, avoiding disruptive full-screen ads.
- No ads appear in the article reader, saved-news screen or while the global switch is off.
- This integration does not include an ad tracking consent / UMP flow. Before serving personalized ads in production, add Google User Messaging Platform consent handling and review applicable Google Play and Nepal privacy requirements.

### Verification
- PHP plugin syntax checked with `php -l`.
- Android manifest and resource XML checked.
- ZIP archives integrity checked.
- Android Gradle compilation and physical-device ad rendering are not certified in this environment; open in Android Studio with JDK 17 and SDK 35, sync Gradle, then run `:app:assembleDebug`. Keep ads disabled until the production App ID, unit IDs and consent flow are configured.

## Phase 6 — Quality assurance and release hardening

### Changes in Phase 6
- Incremented Android version to `versionCode 6` / `versionName 0.6.0`.
- Added JVM unit-test dependencies and WordPress JSON model tests for typical posts, embedded media/authors/categories, and optional/missing API fields.
- Firebase Google Services Gradle plugin is now applied only when the publisher supplies `app/google-services.json`. This keeps source ZIPs free of private Firebase credentials and prevents Gradle sync from failing solely because the file has not yet been supplied.
- Notification permission prompt is requested once on Android 13+ rather than repeatedly prompting on every app launch after denial. Users can enable notifications later in Android system app settings.
- Weather HTTP requests now have bounded connect/read/call timeouts and reject non-success HTTP responses with readable errors.
- Article WebView keeps JavaScript, file access and content access disabled; mixed content is blocked. Links to Sajhedari Daily remain in the reader, while off-site links are handed to Android's external browser/app.
- Updated displayed app version in Settings.
- Added a repeatable source verification script at `scripts/verify-source.sh`.

### Automated tests included
`WordPressModelsTest` covers:
1. Parsing a typical WordPress post with Nepali title/content, categories, featured media and author metadata.
2. Tolerating optional or absent embedded fields without crashing.
3. Parsing a WordPress category response.

Run tests from Android Studio's Gradle tool window (`app > Tasks > verification > testDebugUnitTest`) and build with `app > Tasks > build > assembleDebug`. This source archive does not bundle a Gradle wrapper; once a local Gradle 8.9 installation is available, generate one from the project root with `gradle wrapper --gradle-version 8.9`. Then the commands below can be used:
```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

### Phase 6 verification status
- Android XML parsing: run using `scripts/verify-source.sh`.
- WordPress plugin PHP syntax: run using `scripts/verify-source.sh` when PHP CLI is available.
- Required source/test structure: checked by the script.
- Firebase secret handling: no service account or `google-services.json` is bundled.
- Gradle compilation and emulator/device tests: **not certified in this preparation environment** because an Android SDK and Gradle installation/wrapper are not available here. These remain mandatory before Play Store submission.

### Release checklist — must be completed by the publisher
- [ ] Supply the real Firebase `google-services.json` in `app/` and verify FCM topic delivery.
- [ ] Verify WordPress REST API responses from the target hosting environment.
- [ ] Test Android 8, Android 13 and a current Android release on physical/emulated devices.
- [ ] Verify notification permission granted, denied and later enabled from system settings.
- [ ] Test airplane mode/offline cache, bookmarks after force-stop, and recovery after reconnecting.
- [ ] Test article HTML, external links, images and sharing with the live WordPress content.
- [ ] Test weather with valid, invalid and unavailable city/network inputs.
- [ ] Keep ads disabled; if enabled later, add Google UMP consent flow and replace sample AdMob App ID/unit IDs.
- [ ] Configure release signing, privacy policy URL, Play Data Safety declarations and final screenshots.
- [ ] Run `:app:testDebugUnitTest`, `:app:lint`, and `:app:assembleRelease`; install and smoke-test the signed build.

### Known limitations retained intentionally
- E-paper remains a placeholder until Sajhedari Daily supplies its canonical E-paper archive/PDF URL.
- Weather uses Open-Meteo and a manually entered city; it does not request device location.
- Notification delivery requires publisher Firebase credentials and the WordPress FCM publisher plugin to be configured.
- Automated JVM tests validate JSON model parsing, not live website availability or end-to-end Firebase delivery.

## Phase 7 — Release preparation
- App version advanced to `0.7.0` / version code `7`.
- Adaptive launcher icon placeholder added (replace with publisher-approved logo before public release).
- Release signing configuration reads secrets from environment variables or untracked `local.properties`.
- Release minification/resource shrinking and ProGuard rules configured.
- Privacy policy and Google Play listing drafts added under `docs/release/`.
- See `docs/release/PHASE7-RELEASE-GUIDE.md` for signing, build and submission steps.
- **No signed APK/AAB is included:** a publisher-owned upload keystore and Android SDK/Gradle build environment are required.

## Phase 8 — E-paper integration

The E-paper tab is connected to the Sajhedari Daily E-paper API Bridge. See `docs/EPAPER-INTEGRATION.md` for the endpoint contract, archive pagination, PDF open/download/share behavior, and validation notes.
