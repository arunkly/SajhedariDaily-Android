# Retrofit/Gson models use Gson reflection. Keep annotated model members for JSON parsing.
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.sajhedaridaily.news.data.model.** { *; }
-dontwarn javax.annotation.**
