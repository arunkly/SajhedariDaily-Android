package com.sajhedaridaily.news

import android.content.Context

object AppRuntime { lateinit var context: Context }
