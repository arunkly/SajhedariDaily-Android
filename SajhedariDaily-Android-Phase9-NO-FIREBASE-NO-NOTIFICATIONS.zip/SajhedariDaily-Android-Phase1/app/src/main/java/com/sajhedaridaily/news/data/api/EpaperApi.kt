package com.sajhedaridaily.news.data.api

import com.sajhedaridaily.news.data.model.EpaperResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface EpaperApi {
    @GET("wp-json/sajhedari/v1/epapers")
    suspend fun epapers(
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 20
    ): EpaperResponse
}
