package com.sajhedaridaily.news.data.api

import com.sajhedaridaily.news.data.model.WpCategory
import com.sajhedaridaily.news.data.model.WpPost
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface WordPressApi {
    @GET("wp-json/wp/v2/posts")
    suspend fun posts(
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 20,
        @Query("_embed") embed: Boolean = true,
        @Query("orderby") orderBy: String = "date",
        @Query("order") order: String = "desc",
        @Query("categories") categoryId: Long? = null,
        @Query("search") search: String? = null
    ): List<WpPost>

    @GET("wp-json/wp/v2/posts/{id}")
    suspend fun post(@Path("id") id: Long, @Query("_embed") embed: Boolean = true): WpPost

    @GET("wp-json/wp/v2/categories")
    suspend fun categories(
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 100,
        @Query("hide_empty") hideEmpty: Boolean = true
    ): List<WpCategory>
}
