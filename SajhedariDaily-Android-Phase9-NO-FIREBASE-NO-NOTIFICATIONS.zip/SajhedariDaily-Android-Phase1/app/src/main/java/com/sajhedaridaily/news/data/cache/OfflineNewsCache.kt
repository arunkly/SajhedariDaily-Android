package com.sajhedaridaily.news.data.cache

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.sajhedaridaily.news.data.model.WpPost

/** Lightweight offline cache. Stores only public WordPress content on-device. */
object OfflineNewsCache {
    private const val PREFS = "sajhedari_offline_cache"
    private const val POSTS = "latest_posts"
    private val gson = Gson()
    fun savePosts(context: Context, posts: List<WpPost>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(POSTS, gson.toJson(posts)).apply()
    }
    fun loadPosts(context: Context): List<WpPost> = runCatching {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(POSTS, null) ?: return emptyList()
        gson.fromJson<List<WpPost>>(json, object : TypeToken<List<WpPost>>() {}.type) ?: emptyList()
    }.getOrDefault(emptyList())
    fun saveArticle(context: Context, post: WpPost) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("article_${post.id}", gson.toJson(post)).apply()
    }
    fun loadArticle(context: Context, id: Long): WpPost? = runCatching {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("article_$id", null)?.let { gson.fromJson(it, WpPost::class.java) }
    }.getOrNull()
}
