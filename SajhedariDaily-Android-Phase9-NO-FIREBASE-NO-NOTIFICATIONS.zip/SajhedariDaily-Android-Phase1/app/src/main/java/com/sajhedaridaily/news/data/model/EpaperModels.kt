package com.sajhedaridaily.news.data.model

import com.google.gson.annotations.SerializedName

data class EpaperResponse(
    @SerializedName("items") val items: List<EpaperItem> = emptyList(),
    @SerializedName("page") val page: Int = 1,
    @SerializedName("per_page") val perPage: Int = 20,
    @SerializedName("total") val total: Int = 0,
    @SerializedName("total_pages") val totalPages: Int = 1
)

data class EpaperItem(
    @SerializedName("id") val id: Long,
    @SerializedName("title") val title: String = "",
    @SerializedName("date") val date: String = "",
    @SerializedName("date_gmt") val dateGmt: String = "",
    @SerializedName("pdf_url") val pdfUrl: String = "",
    @SerializedName("thumbnail_url") val thumbnailUrl: String = "",
    @SerializedName("excerpt") val excerpt: String = "",
    @SerializedName("categories") val categories: List<String> = emptyList()
)
