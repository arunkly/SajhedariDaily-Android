package com.sajhedaridaily.news.data.model

import com.google.gson.annotations.SerializedName

data class WpRendered(@SerializedName("rendered") val rendered: String? = null)
data class WpPost(
    val id: Long,
    val date: String? = null,
    val slug: String? = null,
    val link: String? = null,
    val title: WpRendered? = null,
    val content: WpRendered? = null,
    val excerpt: WpRendered? = null,
    val author: Long? = null,
    val categories: List<Long> = emptyList(),
    @SerializedName("_embedded") val embedded: WpEmbedded? = null
)
data class WpCategory(val id: Long, val name: String, val slug: String? = null, val count: Int? = null)
data class WpEmbedded(
    @SerializedName("wp:featuredmedia") val featuredMedia: List<WpMedia>? = null,
    @SerializedName("author") val authors: List<WpAuthor>? = null,
    @SerializedName("wp:term") val terms: List<List<WpCategory>>? = null
)
data class WpMedia(
    @SerializedName("source_url") val sourceUrl: String? = null,
    val alt_text: String? = null
)
data class WpAuthor(val id: Long, val name: String? = null)
