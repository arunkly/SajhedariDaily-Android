package com.sajhedaridaily.news.data.repository

import com.sajhedaridaily.news.data.api.WordPressApi
import com.sajhedaridaily.news.data.model.WpCategory
import com.sajhedaridaily.news.data.model.WpPost

class NewsRepository(private val api: WordPressApi) {
    suspend fun latest(page: Int = 1, categoryId: Long? = null, search: String? = null): List<WpPost> = api.posts(page = page, categoryId = categoryId, search = search)
    suspend fun categories(): List<WpCategory> = api.categories()
    suspend fun article(id: Long): WpPost = api.post(id)
}
