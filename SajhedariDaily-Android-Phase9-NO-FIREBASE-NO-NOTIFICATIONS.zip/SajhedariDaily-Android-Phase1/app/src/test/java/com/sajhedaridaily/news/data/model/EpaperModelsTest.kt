package com.sajhedaridaily.news.data.model

import com.google.gson.Gson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EpaperModelsTest {
    @Test fun parsesBridgeEnvelopeAndNepaliUnicode() {
        val json = """{"items":[{"id":60397,"title":"\u0926\u0948\u0928\u093f\u0915","date":"2026-11-25T00:00:00","date_gmt":"2026-11-24T18:15:00","pdf_url":"https://www.sajhedaridaily.com/wp-content/uploads/2026/11/sample.pdf","thumbnail_url":"","excerpt":"","categories":[]}],"page":1,"per_page":20,"total":1739,"total_pages":87}"""
        val result = Gson().fromJson(json, EpaperResponse::class.java)
        assertEquals(1, result.page)
        assertEquals(20, result.perPage)
        assertEquals(1739, result.total)
        assertEquals(87, result.totalPages)
        assertEquals(60397L, result.items.single().id)
        assertTrue(result.items.single().title.isNotBlank())
        assertTrue(result.items.single().pdfUrl.endsWith("sample.pdf"))
    }
}
