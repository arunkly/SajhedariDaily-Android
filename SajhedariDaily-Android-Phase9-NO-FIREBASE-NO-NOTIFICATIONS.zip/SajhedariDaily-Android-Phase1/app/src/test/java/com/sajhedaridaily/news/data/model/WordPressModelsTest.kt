package com.sajhedaridaily.news.data.model

import com.google.gson.Gson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class WordPressModelsTest {
    private val gson = Gson()

    @Test
    fun parsesTypicalWordPressPostWithEmbeddedMediaAndAuthor() {
        val json = """{
          "id": 418,
          "date": "2026-11-25T10:30:00",
          "slug": "sample-news",
          "link": "https://www.sajhedaridaily.com/sample-news/",
          "title": {"rendered": "समाचार शीर्षक"},
          "content": {"rendered": "<p>समाचार सामग्री</p>"},
          "excerpt": {"rendered": "<p>छोटो विवरण</p>"},
          "author": 3,
          "categories": [7, 9],
          "_embedded": {
            "wp:featuredmedia": [{"source_url": "https://www.sajhedaridaily.com/image.jpg", "alt_text": "समाचार तस्बिर"}],
            "author": [{"id": 3, "name": "सम्पादक"}],
            "wp:term": [[{"id": 7, "name": "राजनीति", "slug": "politics", "count": 12}]]
          }
        }"""

        val post = gson.fromJson(json, WpPost::class.java)
        assertEquals(418L, post.id)
        assertEquals("समाचार शीर्षक", post.title?.rendered)
        assertEquals(listOf(7L, 9L), post.categories)
        assertEquals("https://www.sajhedaridaily.com/image.jpg", post.embedded?.featuredMedia?.first()?.sourceUrl)
        assertEquals("सम्पादक", post.embedded?.authors?.first()?.name)
        assertEquals("राजनीति", post.embedded?.terms?.flatten()?.first()?.name)
    }

    @Test
    fun toleratesOptionalWordPressFieldsBeingAbsent() {
        val post = gson.fromJson("""{"id": 12}""", WpPost::class.java)
        assertEquals(12L, post.id)
        assertNull(post.title)
        assertNull(post.embedded)
        assertNotNull(post.categories)
        assertEquals(0, post.categories.size)
    }

    @Test
    fun parsesCategoryResponse() {
        val category = gson.fromJson("""{"id": 5, "name": "खेलकुद", "slug": "sports", "count": 24}""", WpCategory::class.java)
        assertEquals(5L, category.id)
        assertEquals("खेलकुद", category.name)
        assertEquals(24, category.count)
    }
}
