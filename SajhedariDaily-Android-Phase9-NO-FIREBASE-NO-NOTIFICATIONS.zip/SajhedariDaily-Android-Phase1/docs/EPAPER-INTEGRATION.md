# Sajhedari Daily E-paper integration

The Android app now consumes the companion WordPress E-paper API Bridge:

`GET https://www.sajhedaridaily.com/wp-json/sajhedari/v1/epapers?page=1&per_page=20`

Expected response envelope:

- `items`: published E-paper issues (`id`, `title`, `date`, `date_gmt`, `pdf_url`, `thumbnail_url`, `excerpt`, `categories`)
- `page`, `per_page`, `total`, `total_pages`: archive pagination metadata

The E-paper screen loads the first page automatically, supports refresh and previous/next pagination, displays the total issue count, and provides PDF open, Android Download Manager download, and share-link actions. Nepali Unicode is decoded by Gson. Empty thumbnail URLs use a built-in PDF placeholder.

## Publisher checks

1. Keep the Sajhedari E-paper API Bridge plugin active.
2. Confirm the endpoint is publicly reachable over HTTPS.
3. Confirm every `pdf_url` is a publicly readable PDF URL.
4. The screenshot shared by the publisher showed `total=1739`, `total_pages=87`, `per_page=20`; the app does not hard-code these values and reads them from the API.

## Limitations / validation

- The Android app hands PDF opening to an installed PDF-capable app or browser; an embedded native PDF renderer is not included in this integration.
- The Android Download Manager saves the selected PDF to the public Downloads collection and shows its normal system notification.
- Runtime API, download, and device testing require a real Android build/device and access to the live website. This environment has no Android SDK/Gradle installation, and network DNS access is unavailable; no APK build or live endpoint test is claimed.
