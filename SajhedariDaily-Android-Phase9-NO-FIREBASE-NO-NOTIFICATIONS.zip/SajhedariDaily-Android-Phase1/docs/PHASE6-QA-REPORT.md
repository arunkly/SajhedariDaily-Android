# Sajhedari Daily Android — Phase 6 QA Report

## Baseline
- Input: SajhedariDaily-Android-Phase5.zip
- Application ID: `com.sajhedaridaily.news`
- Release candidate version: `0.6.0` (versionCode 6)
- Minimum Android: API 26
- Compile/target SDK: 35

## Changes made
1. Added WordPress response-model JVM tests.
2. Made Google Services plugin conditional on the presence of publisher-owned `google-services.json`.
3. Prevented repeated notification permission prompts after a denial.
4. Added timeouts and HTTP status checks to weather requests.
5. Hardened article WebView navigation and disabled mixed content/file access.
6. Added source verification script and release checklist.

## Verification boundaries
Source archive and XML/PHP static checks can be performed in this environment. No Android SDK, Gradle executable or Gradle wrapper is available, so a successful APK/AAB build cannot honestly be claimed. The source archive does not bundle a Gradle wrapper; generate it with Gradle 8.9 after opening/configuring the project. Real device, live WordPress, Firebase and Play release tests remain publisher-side gates.

## Release blockers
- Firebase credentials and live push test.
- Android Studio Gradle sync/build/test/lint.
- Physical device smoke tests.
- Release signing and Play Console declarations.
- E-paper URL confirmation if E-paper is expected in initial release.

## Commands
```bash
./scripts/verify-source.sh
gradle wrapper --gradle-version 8.9  # one-time wrapper generation
./gradlew :app:testDebugUnitTest
./gradlew :app:lint
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```
