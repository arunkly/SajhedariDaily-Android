# Phase 9 — Firebase and Notifications Removed

- Removed Firebase Cloud Messaging dependency and Google Services Gradle plugin.
- Removed the Firebase messaging service and topic subscription.
- Removed POST_NOTIFICATIONS permission and notification settings UI.
- Kept the WordPress news feed, E-paper integration, offline cache, language settings, weather, and publisher-controlled advertising integration unchanged.
- App version: 0.8.0 (versionCode 8).

## Build and validation
This source package must be built with Android SDK 35 and Gradle 8.9. Run:
`gradle --no-daemon :app:testDebugUnitTest :app:lint :app:assembleDebug`

A successful compile is not the same as device runtime verification. Install and test on a physical Android device before release.
