# Phase 7 – Release and Play Store preparation

## Project version
- Application ID: `com.sajhedaridaily.news`
- Version name: `0.7.0`
- Version code: `7`
- Minimum Android: API 26 (Android 8.0)
- Compile/target SDK: 35 (re-check current Play target API policy before submission)
- Ads: disabled by default

## Signing key (publisher must create and protect)
Run on a trusted computer with JDK `keytool`:

```bash
keytool -genkeypair -v -keystore sajhedari-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias sajhedari
```

Back up the keystore and passwords securely. Loss of the upload key can delay updates. Never send the keystore or passwords in chat or commit them to Git.

Add the following properties to `~/.gradle/gradle.properties` or the project's untracked `local.properties`:

```properties
SAJHEDARI_STORE_FILE=/absolute/path/to/sajhedari-release.jks
SAJHEDARI_STORE_PASSWORD=your_store_password
SAJHEDARI_KEY_ALIAS=sajhedari
SAJHEDARI_KEY_PASSWORD=your_key_password
```

The build reads these values from environment variables first, then `local.properties`. `keystore.properties.example` is a template only. Do not rename it to a real credentials file inside source control.

## Build commands
Open the project in Android Studio with JDK 17 and Android SDK Platform 35 installed, sync Gradle, then run:

```bash
./gradlew clean testDebugUnitTest assembleDebug
./gradlew bundleRelease
./gradlew assembleRelease
```

The release signing configuration is applied only when `SAJHEDARI_STORE_FILE` is supplied. Do not upload an unsigned AAB/APK. Verify the generated bundle with Android Studio's App Bundle Explorer or `bundletool`, then test the signed build on real devices.

## Before Play Console upload
- [ ] Verify the live WordPress REST API and real article/media/category payloads.
- [ ] Configure Firebase project, `google-services.json`, server-side publisher credentials and test real push delivery.
- [ ] Test bookmarks, offline cache, TTS, PDF/e-paper and weather on supported devices.
- [ ] Replace the temporary vector icon with approved Sajhedari Daily brand artwork if supplied.
- [ ] Confirm app label, package name, version code and signing key.
- [ ] Publish the completed privacy policy at a public HTTPS URL.
- [ ] Complete Play Console Data safety, content rating, target audience and app access declarations truthfully.
- [ ] Supply store icon, feature graphic, screenshots, support email and publisher details.
- [ ] Review current Google Play target API requirements immediately before submission.
- [ ] Test staged/internal track release before production rollout.

## Verification limitation
This source package was checked for archive integrity and XML well-formedness in the preparation environment. Android SDK/Gradle compilation, signed APK/AAB generation, Firebase delivery, live website behavior and physical-device QA have not been executed here. A successful source ZIP is not proof of a release-ready binary.
