# Google Play listing draft

**App name:** Sajhedari Daily – नेपाली समाचार

**Short description (draft):** Sajhedari Daily का ताजा नेपाली समाचार, विचार र अपडेट एउटै एपमा।

**Full description (draft):**

Sajhedari Daily brings the latest news and updates from Sajhedari Daily to your Android phone. Browse recent stories, explore news categories, read full articles, save stories for later and share news with friends and family.

मुख्य सुविधाहरू:
- ताजा समाचार र समाचारका विभिन्न विधा
- विस्तृत समाचार पढ्ने सुविधा
- मनपर्ने समाचार सुरक्षित राख्ने सुविधा
- समाचार खोज्ने र सामाजिक सञ्जालमा साझा गर्ने सुविधा
- उपलब्ध भएमा नयाँ समाचारका सूचना
- नेपाली तथा English interface
- नेटवर्क उपलब्ध नभएको अवस्थामा सुरक्षित गरिएका सामग्री पढ्ने सुविधा

Website: https://www.sajhedaridaily.com/

**Developer/publisher:** [Legal publisher name]  
**Support email:** [Support email]  
**Privacy policy URL:** [Public HTTPS privacy policy URL]

Do not publish until the publisher verifies every feature statement against the release build and supplies the missing legal/contact details.

## Store assets still required
- 512 × 512 px high-resolution app icon (final brand artwork)
- Feature graphic 1024 × 500 px
- At least 2 phone screenshots (recommended 4–8)
- Optional tablet screenshots if tablet support is advertised
- App category, contact details, content rating questionnaire and Data safety declaration
