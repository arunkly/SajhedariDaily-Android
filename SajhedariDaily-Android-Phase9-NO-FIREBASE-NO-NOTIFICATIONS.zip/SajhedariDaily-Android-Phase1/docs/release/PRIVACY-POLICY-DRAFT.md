# Sajhedari Daily – Privacy Policy (publication draft)

**Effective date:** [Insert date]  
**Publisher:** [Insert legal publisher name and contact details]  
**App:** Sajhedari Daily for Android  
**Website:** https://www.sajhedaridaily.com/

This draft must be reviewed and completed by the publisher before it is published or submitted to Google Play. Replace all bracketed fields and ensure it matches the final SDKs, WordPress plugins and Firebase configuration actually deployed.

## Information the app processes

- **News content and preferences:** The app retrieves publicly available articles, categories, featured images and related content from Sajhedari Daily's WordPress website. Saved articles and reading preferences may be stored locally on the device.
- **Push notifications:** If push notifications are configured, Firebase Cloud Messaging may process an app installation token and delivery diagnostics to send publisher-selected news alerts. Users can control notification permission in Android settings.
- **Network and diagnostics:** The app communicates with Sajhedari Daily's website and configured service providers. Those services may receive ordinary technical request information such as IP address, device/network metadata and request timestamps as part of delivering content.
- **Weather:** If the weather feature is enabled, the app may contact the configured weather provider. Disclose any location data or location permission only if the final app actually collects it; this draft does not authorize location collection.
- **Advertising:** Advertising is disabled by default in the current project. If advertising or analytics SDKs are enabled in a future release, this policy and the Google Play Data safety form must be updated before release to accurately describe collection, sharing, consent and opt-out choices.

## Storage and sharing

Cached news and bookmarks are intended to remain on the device. News is shared only when the user invokes Android's sharing interface. Service providers such as Firebase and the hosting provider process data under their own terms and the publisher's configuration.

## Retention and security

Local cached content can be removed by clearing app data or uninstalling the app. Server-side retention for service-provider diagnostics is governed by the publisher's hosting and provider settings. The publisher should use HTTPS, restrict access to credentials and rotate exposed keys.

## Children's privacy

The publisher should add its actual age-appropriateness policy and contact process here. Do not claim the app is directed to children unless the product and compliance requirements have been reviewed.

## Your choices

Users can disable notifications through Android settings and can clear local app data through device settings. For privacy requests, contact **[publisher privacy email]**.

## Changes and contact

The publisher may update this policy when app functionality or service providers change. Contact: **[publisher name, postal address and privacy email]**.
