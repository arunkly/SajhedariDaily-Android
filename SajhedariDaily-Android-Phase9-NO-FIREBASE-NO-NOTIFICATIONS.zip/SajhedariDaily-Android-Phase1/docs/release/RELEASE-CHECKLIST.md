# Release checklist

- [ ] Publisher-approved final logo and icon
- [ ] Keystore generated and backed up
- [ ] Signing secrets configured outside version control
- [ ] Gradle sync and release build successful in Android Studio
- [ ] Signed AAB verified
- [ ] Real-device testing completed
- [ ] WordPress API verified against production site
- [ ] Firebase notifications tested end-to-end
- [ ] Privacy policy published and linked
- [ ] Google Play Data safety and content rating completed
- [ ] Store screenshots and feature graphic prepared
- [ ] Support contact and legal publisher details supplied
- [ ] Internal testing track approved before production rollout
