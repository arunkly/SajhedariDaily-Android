#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

printf '\n[1/5] Validate Android XML resources and manifest...\n'
python3 - <<'PY'
import pathlib, xml.etree.ElementTree as ET
files = list(pathlib.Path('app/src/main').rglob('*.xml'))
for path in files:
    ET.parse(path)
    print(f'  OK {path}')
if not files:
    raise SystemExit('No Android XML files found')
PY

printf '\n[2/5] Validate WordPress plugin PHP syntax...\n'
if command -v php >/dev/null 2>&1; then
  find wordpress-plugin -name '*.php' -print0 | while IFS= read -r -d '' file; do php -l "$file"; done
else
  echo 'SKIP: PHP CLI not installed'
fi

printf '\n[3/5] Check project source structure...\n'
test -f app/src/main/java/com/sajhedaridaily/news/MainActivity.kt
test -f app/src/main/java/com/sajhedaridaily/news/data/api/WordPressApi.kt
test -f app/src/main/java/com/sajhedaridaily/news/notifications/NewsMessagingService.kt
test -f app/src/test/java/com/sajhedaridaily/news/data/model/WordPressModelsTest.kt
echo '  OK required app and test source files exist'

printf '\n[4/5] Check Firebase configuration safety...\n'
if [[ -f app/google-services.json ]]; then
  echo '  Firebase google-services.json present (do not include production secrets in shared ZIPs)'
else
  echo '  OK no Firebase credentials bundled; Firebase Gradle plugin is conditionally applied when supplied'
fi

printf '\n[5/5] Check build tooling...\n'
if [[ -x ./gradlew ]]; then
  ./gradlew :app:testDebugUnitTest :app:assembleDebug
else
  echo '  NOT RUN: Gradle wrapper/Android SDK is not bundled in this environment.'
  echo '  Run in Android Studio: Gradle sync, :app:testDebugUnitTest, :app:assembleDebug'
fi
printf '\nSource verification completed.\n'
