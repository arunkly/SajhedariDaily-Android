<?php
/**
 * Plugin Name: Sajhedari Daily Mobile Ads
 * Description: Publisher-controlled advertising configuration for the Sajhedari Daily Android app. Advertising is disabled by default.
 * Version: 1.0.0
 * Author: Sajhedari Daily
 */
if (!defined('ABSPATH')) { exit; }

final class Sajhedari_Daily_Mobile_Ads {
    const OPTION = 'sajhedari_mobile_ads';
    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'register']);
        add_action('rest_api_init', [$this, 'routes']);
    }
    public function defaults() {
        return [
            'enabled' => 0, 'admob_enabled' => 0, 'direct_enabled' => 0,
            'banner_unit_id' => '', 'interstitial_unit_id' => '',
            'direct_title' => '', 'direct_description' => '', 'direct_image' => '', 'direct_url' => '',
            'show_after_stories' => 5, 'interstitial_every' => 0,
        ];
    }
    public function settings() { return wp_parse_args(get_option(self::OPTION, []), $this->defaults()); }
    public function menu() {
        add_options_page('Sajhedari Mobile Ads', 'Sajhedari Mobile Ads', 'manage_options', 'sajhedari-mobile-ads', [$this, 'page']);
    }
    public function register() {
        register_setting('sajhedari_mobile_ads_group', self::OPTION, [$this, 'sanitize']);
    }
    public function sanitize($input) {
        $d = $this->defaults(); $input = is_array($input) ? $input : [];
        $out = [];
        foreach (['enabled','admob_enabled','direct_enabled'] as $key) $out[$key] = empty($input[$key]) ? 0 : 1;
        foreach (['banner_unit_id','interstitial_unit_id'] as $key) $out[$key] = sanitize_text_field($input[$key] ?? '');
        $out['direct_title'] = sanitize_text_field($input['direct_title'] ?? '');
        $out['direct_description'] = sanitize_textarea_field($input['direct_description'] ?? '');
        $out['direct_image'] = esc_url_raw($input['direct_image'] ?? '');
        $out['direct_url'] = esc_url_raw($input['direct_url'] ?? '');
        $out['show_after_stories'] = max(2, min(20, absint($input['show_after_stories'] ?? 5)));
        $out['interstitial_every'] = max(0, min(20, absint($input['interstitial_every'] ?? 0)));
        return wp_parse_args($out, $d);
    }
    public function routes() {
        register_rest_route('sajhedari/v1', '/ads/config', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'public_config'],
            'permission_callback' => '__return_true',
        ]);
    }
    public function public_config() {
        $s = $this->settings();
        // Return only public placement data; never expose admin data or credentials.
        return rest_ensure_response([
            'enabled' => (bool) $s['enabled'],
            'admob_enabled' => (bool) ($s['enabled'] && $s['admob_enabled']),
            'direct_enabled' => (bool) ($s['enabled'] && $s['direct_enabled']),
            'banner_unit_id' => $s['banner_unit_id'],
            'interstitial_unit_id' => $s['interstitial_unit_id'],
            'direct_title' => $s['direct_title'],
            'direct_description' => $s['direct_description'],
            'direct_image' => $s['direct_image'],
            'direct_url' => $s['direct_url'],
            'show_after_stories' => (int) $s['show_after_stories'],
            'interstitial_every' => (int) $s['interstitial_every'],
        ]);
    }
    public function page() {
        if (!current_user_can('manage_options')) return;
        $s = $this->settings(); $name = self::OPTION;
        ?>
        <div class="wrap">
          <h1>Sajhedari Daily – Mobile Advertising</h1>
          <p>Control advertising in the Sajhedari Daily Android app. All advertising is disabled by default. Save settings and reopen/refresh the app to fetch the public configuration.</p>
          <form method="post" action="options.php">
            <?php settings_fields('sajhedari_mobile_ads_group'); ?>
            <table class="form-table" role="presentation">
              <tr><th scope="row">Enable advertising globally</th><td><label><input type="checkbox" name="<?php echo esc_attr($name); ?>[enabled]" value="1" <?php checked($s['enabled'], 1); ?>> Allow app advertising</label></td></tr>
              <tr><th scope="row">Google AdMob</th><td><label><input type="checkbox" name="<?php echo esc_attr($name); ?>[admob_enabled]" value="1" <?php checked($s['admob_enabled'], 1); ?>> Enable AdMob banner placements</label><p class="description">The Android build contains Google's sample App ID. Replace it with your own production App ID in AndroidManifest.xml before enabling production AdMob.</p></td></tr>
              <tr><th scope="row">AdMob banner unit ID</th><td><input class="regular-text" name="<?php echo esc_attr($name); ?>[banner_unit_id]" value="<?php echo esc_attr($s['banner_unit_id']); ?>" placeholder="ca-app-pub-.../..." /></td></tr>
              <tr><th scope="row">Interstitial unit ID (reserved)</th><td><input class="regular-text" name="<?php echo esc_attr($name); ?>[interstitial_unit_id]" value="<?php echo esc_attr($s['interstitial_unit_id']); ?>" /><p class="description">Stored for a future opt-in interstitial implementation; this build does not display interstitial ads.</p></td></tr>
              <tr><th scope="row">Direct advertisements</th><td><label><input type="checkbox" name="<?php echo esc_attr($name); ?>[direct_enabled]" value="1" <?php checked($s['direct_enabled'], 1); ?>> Enable publisher-managed direct ad card</label></td></tr>
              <tr><th scope="row">Direct ad title</th><td><input class="regular-text" name="<?php echo esc_attr($name); ?>[direct_title]" value="<?php echo esc_attr($s['direct_title']); ?>" /></td></tr>
              <tr><th scope="row">Description</th><td><textarea class="large-text" rows="3" name="<?php echo esc_attr($name); ?>[direct_description]"><?php echo esc_textarea($s['direct_description']); ?></textarea></td></tr>
              <tr><th scope="row">Image URL</th><td><input class="large-text" type="url" name="<?php echo esc_attr($name); ?>[direct_image]" value="<?php echo esc_attr($s['direct_image']); ?>" /></td></tr>
              <tr><th scope="row">Destination URL</th><td><input class="large-text" type="url" name="<?php echo esc_attr($name); ?>[direct_url]" value="<?php echo esc_attr($s['direct_url']); ?>" /></td></tr>
              <tr><th scope="row">Show direct ad after N stories</th><td><input type="number" min="2" max="20" name="<?php echo esc_attr($name); ?>[show_after_stories]" value="<?php echo esc_attr($s['show_after_stories']); ?>" /><p class="description">Placement frequency setting for future feed expansion. Current build shows the direct ad below the featured story.</p></td></tr>
              <tr><th scope="row">Interstitial every N opens (0 = off)</th><td><input type="number" min="0" max="20" name="<?php echo esc_attr($name); ?>[interstitial_every]" value="<?php echo esc_attr($s['interstitial_every']); ?>" /><p class="description">Reserved control; interstitial display is intentionally not active in this release.</p></td></tr>
            </table>
            <?php submit_button('Save advertising settings'); ?>
          </form>
          <hr><h2>Public app configuration endpoint</h2><code><?php echo esc_html(rest_url('sajhedari/v1/ads/config')); ?></code>
        </div>
        <?php
    }
}
new Sajhedari_Daily_Mobile_Ads();
